from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_protect

from payapp.forms import SendMoneyForm, RequestMoneyForm
from payapp.models import Transfer, Request
from register.models import Account


# Create your views here.
@login_required(login_url='/login')
def view_transactions(request):
    incoming = Transfer.objects.filter(Q(receiver=request.user))
    outgoing = Transfer.objects.filter(Q(sender=request.user))

    return render(request, 'webapps2023/payapp/view_transactions.html', {'incoming': incoming, 'outgoing': outgoing})


@csrf_protect
@transaction.atomic
@login_required(login_url='/login')
def view_requests(request):
    if request.method == 'POST':
        confirm = request.POST['confirm']
        status, r_id = confirm.split()

        req = Request.objects.get(id=r_id)

        if status == "accept":
            req.accepted = True

            sender = req.ower
            receiver = req.requester
            amount = req.amount

            t = Transfer(sender=sender, receiver=receiver, amount=amount)
            t.save()

            sender_account = Account.objects.get(user=sender)
            sender_account.amount -= amount
            sender_account.save()

            receiver_account = Account.objects.get(user=receiver)
            receiver_account.amount += amount
            receiver_account.save()

        req.pending = False
        req.save()

        return redirect('view_transactions')

    requests = Request.objects.filter(ower=request.user).filter(pending=True)
    return render(request, 'webapps2023/payapp/view_requests.html', {'requests': requests})


@staff_member_required
@login_required(login_url='/login')
def view_admin_transactions(request):
    transactions = Transfer.objects.all()

    return render(request, 'webapps2023/payapp/view_admin_transactions.html', {'transactions': transactions})


@staff_member_required
@login_required(login_url='/login')
def view_admin_requests(request):
    requests = Request.objects.all()

    return render(request, 'webapps2023/payapp/view_admin_requests.html', {'requests': requests})


@csrf_protect
@transaction.atomic
@login_required(login_url='/login')
def send_money(request):
    if request.method == 'POST':
        form = SendMoneyForm(request.POST)
        if form.is_valid():
            # Make new model for Transaction: sender, receiver, amount
            sender = request.user
            receiver = form.cleaned_data.get('receiver')
            amount = form.cleaned_data.get('amount')

            # Make a new transaction
            # save transaction
            if amount > 0:
                t = Transfer(sender=sender, receiver=receiver, amount=amount)
                t.save()

                sender_account = Account.objects.get(user=sender)
                sender_account.amount -= amount
                sender_account.save()

                receiver_account = Account.objects.get(user=receiver)
                receiver_account.amount += amount
                receiver_account.save()

                return redirect("home")
            else:
                messages.error(request, "You're broke")
    else:
        form = SendMoneyForm()

    return render(request, 'webapps2023/payapp/send_money.html', {"form":form})


@csrf_protect
@transaction.atomic
@login_required(login_url='/login')
def request_money(request):
    if request.method == 'POST':
        form = RequestMoneyForm(request.POST)
        if form.is_valid():
            # Make new model for Transaction: sender, receiver, amount
            requester = request.user
            ower = form.cleaned_data.get('ower')
            amount = form.cleaned_data.get('amount')

            # check amount > 0
            if amount > 0:
                r = Request(requester=requester, ower=ower, amount=amount)
                r.save()
            else:
                messages.error(request, "You're broke")

            return redirect("home")
    else:
        form = RequestMoneyForm()

    return render(request, 'webapps2023/payapp/request_money.html', {"form":form})