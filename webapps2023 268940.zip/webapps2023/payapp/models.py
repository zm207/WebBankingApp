from django.contrib.auth.models import User
from django.db import models


# Create your models here.
class Transfer(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sender")
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="receiver")
    amount = models.DecimalField(decimal_places=2, max_digits=12)
    timestamp = models.DateTimeField(auto_now_add=True)


class Request(models.Model):
    requester = models.ForeignKey(User, on_delete=models.CASCADE, related_name="requester")
    ower = models.ForeignKey(User, on_delete=models.CASCADE, related_name="ower")
    amount = models.DecimalField(decimal_places=2, max_digits=12)
    timestamp = models.DateTimeField(auto_now_add=True)
    pending = models.BooleanField(default=True)
    accepted = models.BooleanField(default=False)
