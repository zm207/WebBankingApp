from django.urls import path, include

from payapp.views import send_money
from . import views


# app_name = 'webapps2023'
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('home/', views.home, name='home'),
    path('', views.home),
    # path('transactions/', views.transactions, name='transactions'),
    # path('welcome/', views.welcome, name='welcome'),
    # path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    # path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('login/', views.login_user, name='login_user'),
    path('logout/', views.logout_user, name='logout_user'),
    path('register/', views.register_user, name='register_user'),
    path('webapps2023/', include('payapp.urls')),
]