from django.views.decorators.csrf import csrf_protect

from payapp.forms import SendMoneyForm
from register.models import Account

from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse
from django.shortcuts import render, redirect
from register.forms import RegisterForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from register.models import Account

# from .forms import UserLoginForm, UserRegistrationForm, AdminLoginForm

# Create your views here.
@csrf_protect
def home(request):
    # if request.method == "POST":
    #     form = SendMoneyForm(request.POST)
    #     if form.is_valid():
    #         #a = Account(amount=form.cleaned_data.get('amount'))
    #         #a.save()
    #         pass
    # else:
    #     form = SendMoneyForm()
    if request.user.is_authenticated:
        account = Account.objects.get(user_id=request.user.id)
        return render(request, 'webapps2023/register/home.html', {'balance': account.amount})
    return render(request, 'webapps2023/register/home.html')

    # print(Account.objects.select_related().all())
    #
    #
    # form = SendMoneyForm()
    # return render(request, 'webapps2023/register/registration.html', {"form": form})

# def welcome(request):
#     return render(request, 'register/welcome.html')


# def transactions(request):
#     transactions = Account.objects.all()
#     return render(request, 'register1/transactions.html', {'transactions': transactions})




@csrf_protect
def register_user(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            # login(request, user)
            return redirect("home")
            # messages.success(request, "Registration successful.")
            # return HttpResponse("Homepage")
        messages.error(request, "Unsuccessful registration. Invalid information.")
    form = RegisterForm()
    return render(request, "webapps2023/register/registration.html", {"register_user": form})


@csrf_protect
def login_user(request):
    if request.method == "POST":
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                # return render(request, "webapps2023/register/home.html")
                return redirect("home")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request, "webapps2023/register/login.html", {"login_user": form})


def logout_user(request):
    logout(request)
    messages.info(request, "You have successfully logged out.")
    return redirect("home")




# def user_login(request):
#     if request.method == 'POST':
#         form = UserLoginForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             password = form.cleaned_data['password']
#             user = authenticate(username=username, password=password)
#             if user is not None:
#                 if user.is_active:
#                     login(request, user)
#                     return redirect('home')
#                 else:
#                     messages.error(request, 'Your account is disabled.')
#             else:
#                 messages.error(request, 'Invalid username or password.')
#     else:
#         form = UserLoginForm()
#
#     return render(request, 'login.html', {'form': form})


# def user_logout(request):
#     logout(request)
#     return redirect('home')


# def user_register(request):
#     if request.method == 'POST':
#         form = UserRegistrationForm(request.POST)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.set_password(form.cleaned_data['password'])
#             user.save()
#             return redirect('login')
#     else:
#         form = UserRegistrationForm()
#
#     return render(request, 'webapps2023/register/registration.html', {'form': form})


# def admin_login(request):
#     if request.method == 'POST':
#         form = AdminLoginForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             password = form.cleaned_data['password']
#             user = authenticate(username=username, password=password)
#             if user is not None and user.admin is not None:
#                 if user.is_active:
#                     login(request, user)
#                     return redirect('admin_home')
#                 else:
#                     messages.error(request, 'Your account is disabled.')
#             else:
#                 messages.error(request, 'Invalid username or password.')
#     else:
#         form = AdminLoginForm()
#
#     return render(request, 'webapps2023/register/admin_login.html', {'form': form})